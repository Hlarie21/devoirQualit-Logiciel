package com.articlee.service;

import java.util.ArrayList;  
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;  
import com.articlee.entity.Articlee;  
import com.articlee.repository.ArticleeRepository;  

@Service  
public class ArticleeService {
	
	@Autowired  
	ArticleeRepository articleeRepository;  
	public List<Articlee> getAllArticlee()   
	{  
	List<Articlee> articlee = new ArrayList<Articlee>();  
	articleeRepository.findAll().forEach(articlee1 -> articlee.add(articlee1));  
	return articlee;  
	}  
	public Articlee getArticleeById(int id)   
	{  
	return articleeRepository.findById(id).get();  
	}  
	public void saveOrUpdate(Articlee articlee)   
	{  
	articleeRepository.save(articlee);  
	}  
	public void delete(int id)   
	{  
	articleeRepository.deleteById(id);  
	}  
	public void update(Articlee articlee, int articleid)   
	{  
	articleeRepository.save(articlee);  
	}  

}