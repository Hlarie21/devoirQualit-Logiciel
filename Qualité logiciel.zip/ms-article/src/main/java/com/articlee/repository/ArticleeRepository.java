package com.articlee.repository;  

import org.springframework.data.repository.CrudRepository;  
import com.articlee.entity.*;  

  
public interface ArticleeRepository extends CrudRepository<Articlee, Integer> {
	
}