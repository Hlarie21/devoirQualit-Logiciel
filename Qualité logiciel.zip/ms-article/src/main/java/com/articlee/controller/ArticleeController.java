package com.articlee.controller;
 
import java.util.List;  

import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.DeleteMapping;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.PutMapping;  
import org.springframework.web.bind.annotation.RequestBody;  
import org.springframework.web.bind.annotation.RestController;

import com.articlee.service.ArticleeService;
import com.articlee.entity.Articlee;

@RestController  
public class ArticleeController {
	
	@Autowired  
	ArticleeService articleeService;  
	
	@GetMapping("/article")  
	private List<Articlee> getAllArticlee()   
	{  
	return articleeService.getAllArticlee();  
	}    
	
	@GetMapping("/article/{articleid}")  
	private Articlee getArticlee(@PathVariable("articleid") int articleid)   
	{  
	return articleeService.getArticleeById(articleid);  
	}  
	@DeleteMapping("/article/{articleid}")  
	private void deleteArticlee(@PathVariable("articleid") int articleid)   
	{  
	articleeService.delete(articleid);  
	}    
	@PostMapping("/articles")  
	private int saveArticlee(@RequestBody Articlee articlee)   
	{  
	articleeService.saveOrUpdate(articlee);  
	return articlee.getArticleid();  
	}  
	@PutMapping("/articles")  
	private Articlee update(@RequestBody Articlee articlee)   
	{  
	articleeService.saveOrUpdate(articlee);  
	return articlee;  
	}  

}